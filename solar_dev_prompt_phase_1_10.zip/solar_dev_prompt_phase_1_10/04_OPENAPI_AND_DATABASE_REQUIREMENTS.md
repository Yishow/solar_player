# OpenAPI 與 SQLite Database Requirements

本檔定義本系統的 API 與資料庫最低要求。Coding agent 實作時，每新增或修改 API 必須同步更新 `docs/openapi.yaml`；每新增或修改 table 必須同步更新 `docs/database-schema.sql`。

---

## 1. API response 統一格式

```ts
export type ApiResponse<T> = {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
    details?: unknown
  }
}
```

成功：

```json
{
  "success": true,
  "data": {}
}
```

失敗：

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request body",
    "details": []
  }
}
```

---

## 2. OpenAPI 必備 endpoints

### Health / Docs

- [ ] `GET /health`
- [ ] `GET /docs`

### Metrics

- [ ] `GET /api/metrics/live`
- [ ] `GET /api/metrics/history?range=day|week|month|year|total`
- [ ] `GET /api/metrics/daily-summary`
- [ ] `GET /api/metrics/cumulative`

### MQTT Settings

- [ ] `GET /api/settings/mqtt`
- [ ] `PUT /api/settings/mqtt`
- [ ] `POST /api/settings/mqtt/test`
- [ ] `POST /api/settings/mqtt/reload`
- [ ] `GET /api/settings/mqtt/topics`
- [ ] `POST /api/settings/mqtt/topics`
- [ ] `PUT /api/settings/mqtt/topics/{id}`
- [ ] `DELETE /api/settings/mqtt/topics/{id}`
- [ ] `PUT /api/settings/mqtt/topics/reorder`
- [ ] `GET /api/settings/mqtt/live-preview`

### Playback

- [ ] `GET /api/playback/settings`
- [ ] `PUT /api/playback/settings`
- [ ] `GET /api/playback/pages`
- [ ] `PUT /api/playback/pages`

### Images

- [ ] `GET /api/images`
- [ ] `POST /api/images`
- [ ] `PUT /api/images/{id}`
- [ ] `DELETE /api/images/{id}`
- [ ] `PUT /api/images/reorder`
- [ ] `GET /api/images/storage`

### Circuits

- [ ] `GET /api/circuits`
- [ ] `POST /api/circuits`
- [ ] `PUT /api/circuits/{id}`
- [ ] `DELETE /api/circuits/{id}`
- [ ] `PUT /api/circuits/reorder`
- [ ] `GET /api/circuits/live`

### Device

- [ ] `GET /api/device/status`
- [ ] `POST /api/device/reboot`
- [ ] `POST /api/device/clear-cache`
- [ ] `GET /api/device/logs`
- [ ] `GET /api/device/logs/export`

---

## 3. SQLite schema 要求

### `schema_migrations`

```sql
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `system_settings`

```sql
CREATE TABLE IF NOT EXISTS system_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  value_type TEXT NOT NULL DEFAULT 'string',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `mqtt_settings`

```sql
CREATE TABLE IF NOT EXISTS mqtt_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  enabled INTEGER NOT NULL DEFAULT 1,
  mode TEXT NOT NULL DEFAULT 'mqtt',
  protocol TEXT NOT NULL DEFAULT 'mqtt',
  broker_url TEXT NOT NULL DEFAULT 'localhost',
  port INTEGER NOT NULL DEFAULT 1883,
  username TEXT,
  password_encrypted TEXT,
  client_id TEXT NOT NULL DEFAULT 'kuozui-green-display-01',
  reconnect_interval_sec INTEGER NOT NULL DEFAULT 30,
  message_timeout_sec INTEGER NOT NULL DEFAULT 60,
  keepalive_sec INTEGER NOT NULL DEFAULT 60,
  clean INTEGER NOT NULL DEFAULT 1,
  last_connection_status TEXT NOT NULL DEFAULT 'disconnected',
  last_message_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `topic_mappings`

```sql
CREATE TABLE IF NOT EXISTS topic_mappings (
  id TEXT PRIMARY KEY,
  mapping_type TEXT NOT NULL DEFAULT 'core',
  metric_key TEXT NOT NULL,
  label_zh TEXT NOT NULL,
  label_en TEXT NOT NULL,
  topic TEXT NOT NULL,
  unit TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  value_path TEXT,
  timestamp_path TEXT,
  quality_path TEXT,
  multiplier REAL NOT NULL DEFAULT 1,
  offset REAL NOT NULL DEFAULT 0,
  decimals INTEGER,
  min_value REAL,
  max_value REAL,
  stale_after_sec INTEGER,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_topic_mappings_metric_key
ON topic_mappings(metric_key);

CREATE INDEX IF NOT EXISTS idx_topic_mappings_topic
ON topic_mappings(topic);
```

### `live_metric_values`

```sql
CREATE TABLE IF NOT EXISTS live_metric_values (
  metric_key TEXT PRIMARY KEY,
  mapping_id TEXT,
  topic TEXT NOT NULL,
  value REAL,
  unit TEXT NOT NULL,
  quality TEXT NOT NULL DEFAULT 'good',
  raw_payload TEXT,
  received_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (mapping_id) REFERENCES topic_mappings(id)
);
```

### `metric_snapshots`

```sql
CREATE TABLE IF NOT EXISTS metric_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  metric_key TEXT NOT NULL,
  value REAL NOT NULL,
  unit TEXT NOT NULL,
  quality TEXT NOT NULL DEFAULT 'good',
  captured_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_metric_snapshots_key_time
ON metric_snapshots(metric_key, captured_at);
```

### `daily_energy_summaries`

```sql
CREATE TABLE IF NOT EXISTS daily_energy_summaries (
  date TEXT PRIMARY KEY,
  generation_kwh REAL NOT NULL DEFAULT 0,
  self_consumption_kwh REAL NOT NULL DEFAULT 0,
  consumption_kwh REAL NOT NULL DEFAULT 0,
  co2_reduction_t REAL NOT NULL DEFAULT 0,
  peak_generation_kw REAL,
  peak_generation_at TEXT,
  peak_consumption_kw REAL,
  peak_consumption_at TEXT,
  self_consumption_ratio REAL,
  system_efficiency REAL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `cumulative_counters`

```sql
CREATE TABLE IF NOT EXISTS cumulative_counters (
  counter_key TEXT PRIMARY KEY,
  value REAL NOT NULL DEFAULT 0,
  unit TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'mqtt',
  last_source_value REAL,
  last_updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `circuit_configs`

```sql
CREATE TABLE IF NOT EXISTS circuit_configs (
  id TEXT PRIMARY KEY,
  display_order INTEGER NOT NULL,
  name_zh TEXT NOT NULL,
  name_en TEXT NOT NULL,
  icon TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'kW',
  mqtt_topic TEXT NOT NULL,
  value_path TEXT,
  multiplier REAL NOT NULL DEFAULT 1,
  offset REAL NOT NULL DEFAULT 0,
  rated_capacity REAL NOT NULL DEFAULT 100,
  normal_min REAL NOT NULL DEFAULT 0,
  normal_max REAL NOT NULL DEFAULT 70,
  attention_min REAL NOT NULL DEFAULT 70,
  attention_max REAL NOT NULL DEFAULT 90,
  warning_min REAL NOT NULL DEFAULT 90,
  warning_max REAL NOT NULL DEFAULT 100,
  show INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `image_assets`

```sql
CREATE TABLE IF NOT EXISTS image_assets (
  id TEXT PRIMARY KEY,
  filename TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  width INTEGER,
  height INTEGER,
  title TEXT,
  description TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  duration_sec INTEGER NOT NULL DEFAULT 10,
  aspect_ratio TEXT NOT NULL DEFAULT '16:9',
  include_in_slideshow INTEGER NOT NULL DEFAULT 1,
  is_cover INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `playback_pages`

```sql
CREATE TABLE IF NOT EXISTS playback_pages (
  page_key TEXT PRIMARY KEY,
  title_zh TEXT NOT NULL,
  title_en TEXT NOT NULL,
  route TEXT NOT NULL,
  display_order INTEGER NOT NULL,
  duration_sec INTEGER NOT NULL DEFAULT 10,
  enabled INTEGER NOT NULL DEFAULT 1,
  thumbnail_url TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `playback_settings`

```sql
CREATE TABLE IF NOT EXISTS playback_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  autoplay INTEGER NOT NULL DEFAULT 1,
  loop_mode INTEGER NOT NULL DEFAULT 1,
  start_page_key TEXT NOT NULL DEFAULT 'overview',
  transition_type TEXT NOT NULL DEFAULT 'fade',
  transition_speed TEXT NOT NULL DEFAULT 'medium',
  schedule_enabled INTEGER NOT NULL DEFAULT 0,
  schedule_start TEXT NOT NULL DEFAULT '08:00',
  schedule_end TEXT NOT NULL DEFAULT '18:00',
  repeat_days TEXT NOT NULL DEFAULT '[1,2,3,4,5]',
  idle_mode TEXT NOT NULL DEFAULT 'static-page',
  idle_minutes INTEGER NOT NULL DEFAULT 5,
  brightness INTEGER NOT NULL DEFAULT 70,
  orientation TEXT NOT NULL DEFAULT 'landscape',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### `device_events`

```sql
CREATE TABLE IF NOT EXISTS device_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  level TEXT NOT NULL,
  event_type TEXT NOT NULL,
  message TEXT NOT NULL,
  payload TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_device_events_created_at
ON device_events(created_at);
```

---

## 4. Seed data 要求

系統第一次啟動時要建立：

- MQTT settings default row
- Core topic mappings
- Circuit configs
- Playback pages：overview、solar、factory-circuit、images、sustainability
- Playback settings row
- Cumulative counters：total_generation_kwh、total_co2_reduction_t、total_consumption_kwh、total_self_consumption_kwh
- CO₂ emission factor setting

---

## 5. Migration 原則

- [ ] migration 必須可重複執行
- [ ] migration version 必須記錄
- [ ] 不可在 production 啟動時刪除使用者資料
- [ ] schema 修改要向後相容
- [ ] seed 只補缺失資料，不覆蓋使用者設定
