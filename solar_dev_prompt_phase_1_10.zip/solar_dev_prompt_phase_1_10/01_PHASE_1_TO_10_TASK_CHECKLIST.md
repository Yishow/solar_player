# Solar Display System — Phase 1–10 Task Checklist

> 使用方式：每完成一項就勾選。每個 Phase 完成後，必須先跑 build / typecheck / server startup / frontend startup，再進下一個 Phase。

---

## Phase 1 — Monorepo、基礎架構、OpenAPI、SQLite 初始化

### 專案初始化

- [ ] 建立 `solar-display/` monorepo
- [ ] 建立 `pnpm-workspace.yaml`
- [ ] 建立 root `package.json`
- [ ] 建立 root `tsconfig.base.json`
- [ ] 建立 `apps/web`
- [ ] 建立 `apps/server`
- [ ] 建立 `packages/shared`
- [ ] 建立 `.env.example`
- [ ] 建立 `README.md`

### Frontend skeleton

- [ ] 建立 Vite + React + TypeScript
- [ ] 安裝 React Router
- [ ] 建立 `src/app/router.tsx`
- [ ] 建立 `LayoutShell`
- [ ] 建立 `AppHeader`
- [ ] 建立 `AppFooterNav`
- [ ] 建立 `PageContainer`
- [ ] 建立 `styles/tokens.css`
- [ ] 建立 `styles/global.css`
- [ ] 建立首頁 placeholder

### Backend skeleton

- [ ] 建立 Fastify TypeScript app
- [ ] 建立 `server.ts`
- [ ] 建立 `app.ts`
- [ ] 建立 config loader
- [ ] 建立 `/health`
- [ ] 建立 `/docs`
- [ ] 掛載 Swagger UI
- [ ] 建立 error handler
- [ ] 建立 unified API response helper

### SQLite

- [ ] 建立 `data/` 目錄
- [ ] 建立 SQLite connection
- [ ] 建立 migration runner
- [ ] 建立 `schema_migrations`
- [ ] 建立 `system_settings`
- [ ] 建立 `mqtt_settings`
- [ ] 建立 `topic_mappings`
- [ ] 建立 `live_metric_values`
- [ ] 建立 `metric_snapshots`
- [ ] 建立 `daily_energy_summaries`
- [ ] 建立 `cumulative_counters`
- [ ] 建立 `circuit_configs`
- [ ] 建立 `image_assets`
- [ ] 建立 `playback_pages`
- [ ] 建立 `playback_settings`
- [ ] 建立 `device_events`
- [ ] seed default records

### Shared types

- [ ] 建立 `ApiResponse<T>`
- [ ] 建立 `MetricKey`
- [ ] 建立 `LiveMetrics`
- [ ] 建立 `MqttTopicMapping`
- [ ] 建立 `MqttStatus`
- [ ] 建立 `CircuitConfig`
- [ ] 建立 `PlaybackSettings`
- [ ] 建立 `ImageAsset`
- [ ] 建立 `DeviceStatus`

---

## Phase 2 — UI Shell 與 14 個頁面骨架

### Routes

- [ ] `/overview`
- [ ] `/solar`
- [ ] `/factory-circuit`
- [ ] `/images`
- [ ] `/sustainability`
- [ ] `/trends`
- [ ] `/settings/playback`
- [ ] `/settings/images`
- [ ] `/settings/mqtt`
- [ ] `/settings/circuits`
- [ ] `/history`
- [ ] `/offline`
- [ ] `/slideshow-preview`
- [ ] `/device-status`

### Common UI components

- [ ] `MetricCard`
- [ ] `IconCircle`
- [ ] `StatusBadge`
- [ ] `Sparkline`
- [ ] `PanelCard`
- [ ] `SectionTitle`
- [ ] `PageNumberPill`
- [ ] `DataCardGrid`
- [ ] `BilingualLabel`
- [ ] `FlowNode`
- [ ] `FlowConnector`
- [ ] `LeafOrnament`
- [ ] `KioskButton`
- [ ] `KioskInput`
- [ ] `KioskSelect`
- [ ] `KioskToggle`

### Header / footer

- [ ] Header logo
- [ ] Header Chinese title
- [ ] Header English title
- [ ] Header clock
- [ ] Header date
- [ ] Header weather mock
- [ ] Header MQTT status badge
- [ ] Footer page number
- [ ] Footer navigation tabs
- [ ] Footer slogan
- [ ] Footer leaf ornament

---

## Phase 3 — Mock Data Layer 與展示頁實作

### Mock data

- [ ] 建立 frontend mock metrics
- [ ] 建立 frontend mock circuits
- [ ] 建立 frontend mock images
- [ ] 建立 frontend mock sustainability KPIs
- [ ] 建立 backend mock fallback service

### Overview

- [ ] hero area
- [ ] 即時發電功率 card
- [ ] 今日發電量 card
- [ ] 累積發電量 card
- [ ] 今日 CO₂ 減量 card
- [ ] 累積 CO₂ 減量 card
- [ ] sparkline placeholder

### Solar

- [ ] 左側標題與說明
- [ ] solar panels node
- [ ] inverter node
- [ ] factory consumption node
- [ ] carbon reduction node
- [ ] flow connector
- [ ] KPI cards

### Factory Circuit

- [ ] 太陽能板 node
- [ ] 逆變器 node
- [ ] 配電盤 node
- [ ] circuit list
- [ ] circuit percentage
- [ ] bottom KPI cards

### Images

- [ ] hero image
- [ ] thumbnail carousel
- [ ] image info card
- [ ] slideshow progress
- [ ] prev / next control

### Sustainability

- [ ] hero background
- [ ] total generation card
- [ ] total CO₂ card
- [ ] annual saving card
- [ ] green procurement card
- [ ] ESG highlights card
- [ ] trees planted card

---

## Phase 4 — MQTT.js 整合與 MQTT Settings

### MQTT backend

- [ ] 安裝 MQTT.js
- [ ] 建立 `MqttClientService`
- [ ] 建立 `MqttConnectionManager`
- [ ] 建立 `MqttTopicRegistry`
- [ ] 建立 `MqttPayloadParser`
- [ ] 建立 `MqttStatusService`
- [ ] 支援 mqtt mode
- [ ] 支援 mock mode
- [ ] 支援 reconnect
- [ ] 支援 message timeout
- [ ] 支援 topic mapping reload
- [ ] 支援 wildcard 訂閱策略，若需要

### MQTT parser

- [ ] 支援 primitive number
- [ ] 支援 number string
- [ ] 支援 `{ value }`
- [ ] 支援 `{ value, unit, timestamp }`
- [ ] 支援 configurable value path，例如 `data.power`
- [ ] 支援 multiplier
- [ ] 支援 offset
- [ ] 支援 decimal places
- [ ] 支援 min / max validation
- [ ] 支援 bad quality 不更新 UI
- [ ] 保留 raw payload 供 debug

### MQTT settings API

- [ ] `GET /api/settings/mqtt`
- [ ] `PUT /api/settings/mqtt`
- [ ] `POST /api/settings/mqtt/test`
- [ ] `GET /api/settings/mqtt/topics`
- [ ] `PUT /api/settings/mqtt/topics`
- [ ] `POST /api/settings/mqtt/reload`
- [ ] 儲存 broker settings 到 SQLite
- [ ] 儲存 topic mappings 到 SQLite
- [ ] 儲存 password 時避免明文回傳 API

### MQTT Settings UI

- [ ] Data mode toggle：MQTT / Mock
- [ ] Broker host
- [ ] Port
- [ ] Username
- [ ] Password
- [ ] Client ID
- [ ] Reconnect interval
- [ ] Message timeout
- [ ] Test connection button
- [ ] Save settings button
- [ ] Live topic list
- [ ] Topic mapping form
- [ ] Metric key dropdown
- [ ] Topic input
- [ ] Unit input
- [ ] Value path input
- [ ] Enabled toggle
- [ ] Live data preview
- [ ] Last update time

---

## Phase 5 — Socket.IO 即時推送與 Offline Error

### Backend realtime

- [ ] 安裝 Socket.IO
- [ ] 建立 Socket.IO server
- [ ] 建立 client connection handler
- [ ] 建立 `liveMetrics:update`
- [ ] 建立 `mqtt:status`
- [ ] 建立 `circuitMetrics:update`
- [ ] 建立 `playback:settingsUpdated`
- [ ] 建立 `images:updated`
- [ ] 建立 `deviceStatus:update`
- [ ] 建立 `system:error`
- [ ] 建立 `system:recovered`

### Frontend realtime

- [ ] 建立 socket singleton
- [ ] 建立 reconnect 設定
- [ ] 建立 listener cleanup
- [ ] 建立 `useLiveMetrics`
- [ ] 建立 `useMqttStatus`
- [ ] 建立 `useCircuitMetrics`
- [ ] Header MQTT 狀態即時更新
- [ ] 展示頁 KPI 即時更新

### Offline Error

- [ ] MQTT disconnected 顯示 offline 狀態
- [ ] MQTT connected 但 no message timeout 顯示 stale
- [ ] 進入 Offline Error Display
- [ ] 顯示最後更新時間
- [ ] 顯示錯誤原因
- [ ] 顯示建議處理方式
- [ ] 顯示 retry countdown
- [ ] 連線恢復後回原播放頁

---

## Phase 6 — SQLite 累積值、快照、歷史資料

### Accumulator

- [ ] 建立 `MetricsAccumulatorService`
- [ ] 啟動時載入 `cumulative_counters`
- [ ] 若 MQTT 有 total value，優先用 total
- [ ] 若 MQTT 只有 power，使用 kW 時間積分估算 kWh
- [ ] deltaSeconds 超過上限時不積分
- [ ] 第一筆資料不跨重啟積分
- [ ] CO₂ factor 可設定
- [ ] 寫入節流，避免高頻寫 DB

### Snapshots

- [ ] 每 30 或 60 秒寫 snapshot
- [ ] 寫入 generation
- [ ] 寫入 consumption
- [ ] 寫入 self consumption
- [ ] 寫入 CO₂
- [ ] 寫入 ratio
- [ ] 寫入 efficiency

### Daily summary

- [ ] 每日 generation total
- [ ] 每日 consumption total
- [ ] 每日 self consumption total
- [ ] 每日 CO₂ total
- [ ] peak generation
- [ ] peak generation time
- [ ] peak consumption
- [ ] peak consumption time
- [ ] day rollover 處理

### History API / UI

- [ ] `GET /api/metrics/history`
- [ ] `GET /api/metrics/daily-summary`
- [ ] `GET /api/metrics/cumulative`
- [ ] Energy Trend Summary 圖表
- [ ] Energy Data History 圖表
- [ ] day/week/month/year/total 切換

---

## Phase 7 — Playback Engine 播放系統

### Backend

- [ ] `GET /api/playback/settings`
- [ ] `PUT /api/playback/settings`
- [ ] `GET /api/playback/pages`
- [ ] `PUT /api/playback/pages`
- [ ] 設定更新後 broadcast

### Frontend playback

- [ ] `usePlaybackController`
- [ ] `usePageRotation`
- [ ] `useCountdown`
- [ ] autoplay
- [ ] loop
- [ ] start page
- [ ] transition type
- [ ] transition speed
- [ ] schedule enabled
- [ ] schedule start / end
- [ ] repeat days
- [ ] idle mode
- [ ] idle timeout
- [ ] brightness
- [ ] orientation

### UI

- [ ] Playback Settings route preview
- [ ] Playback Settings duration editor
- [ ] Playback Settings page order
- [ ] Playback Settings enable/disable page
- [ ] Slideshow Preview current page card
- [ ] Slideshow Preview countdown
- [ ] Slideshow Preview playback summary

---

## Phase 8 — Image Management 圖片管理

### Backend

- [ ] 建立 uploads/images 目錄
- [ ] `GET /api/images`
- [ ] `POST /api/images`
- [ ] `PUT /api/images/:id`
- [ ] `DELETE /api/images/:id`
- [ ] `PUT /api/images/reorder`
- [ ] 驗證 jpg/png/webp
- [ ] 讀取 width/height
- [ ] 儲存 file size
- [ ] 刪除 DB record 與實體檔案
- [ ] 計算 used storage

### Frontend

- [ ] upload dropzone
- [ ] image grid
- [ ] image card
- [ ] selected image panel
- [ ] title edit
- [ ] description edit
- [ ] display duration edit
- [ ] aspect ratio setting
- [ ] include in slideshow toggle
- [ ] set as cover
- [ ] remove image
- [ ] Images playback page 使用 enabled images

---

## Phase 9 — Circuit Settings 與 Factory Circuit 動態化

### Backend

- [ ] `GET /api/circuits`
- [ ] `POST /api/circuits`
- [ ] `PUT /api/circuits/:id`
- [ ] `DELETE /api/circuits/:id`
- [ ] `PUT /api/circuits/reorder`
- [ ] circuit topic 訂閱更新
- [ ] load percentage 計算
- [ ] threshold status 計算
- [ ] circuit socket event

### Frontend

- [ ] Circuit Settings table
- [ ] drag reorder
- [ ] display order input
- [ ] name zh/en edit
- [ ] icon select
- [ ] unit select
- [ ] MQTT topic input
- [ ] rated capacity input
- [ ] normal range input
- [ ] attention range input
- [ ] warning range input
- [ ] show toggle
- [ ] Factory Circuit 動態 render
- [ ] status color dynamic

---

## Phase 10 — Device Status、部署、穩定化、最終驗收

### Device status

- [ ] `GET /api/device/status`
- [ ] `POST /api/device/reboot`
- [ ] `POST /api/device/clear-cache`
- [ ] `GET /api/device/logs`
- [ ] `GET /api/device/logs/export`
- [ ] uptime
- [ ] OS
- [ ] app version
- [ ] local IP
- [ ] MAC address
- [ ] MQTT status
- [ ] data source
- [ ] CPU usage
- [ ] memory usage
- [ ] disk usage
- [ ] temperature
- [ ] network signal if available

### Deployment

- [ ] production build script
- [ ] `.env.production.example`
- [ ] Raspberry Pi systemd service
- [ ] Chromium kiosk launch script
- [ ] SQLite backup script
- [ ] uploads folder permission check
- [ ] log rotation notes
- [ ] README deployment guide

### Final tests

- [ ] frontend build
- [ ] backend build
- [ ] typecheck
- [ ] lint
- [ ] API smoke test
- [ ] Socket smoke test
- [ ] MQTT mock mode test
- [ ] MQTT real mode test
- [ ] SQLite restart persistence test
- [ ] Kiosk 1920x1080 visual check
