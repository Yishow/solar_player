# Solar Display System — 完整開發系統提示詞 Phase 1–10

你是一位資深 Full-stack Engineer、系統架構師與 kiosk display 系統開發者。請協助我實作「太陽能綠能展示播放系統」。

系統用途：部署於 Raspberry Pi / Linux mini PC / kiosk browser，在 1920x1080 大螢幕上展示工廠太陽能發電、廠區用電、CO₂ 減量、用電迴路、圖片輪播、永續成果、MQTT 即時資料、歷史趨勢、播放設定、圖片管理與裝置狀態。

請嚴格分 Phase 1–10 開發。每個 Phase 完成後都要能 build、能啟動、型別正確、API 文件同步、SQLite schema 同步，不要跨 phase 偷做大量未要求功能。

---

## 0. 技術選型與硬性限制

### Frontend

- Vite
- React
- TypeScript
- React Router
- Zustand 優先作為 client state store
- TanStack Query 可用於 REST API state
- Socket.IO client 優先；若改用原生 WebSocket，必須提供 reconnect、heartbeat、event envelope
- Recharts 優先作為趨勢圖表
- Tailwind + CSS variables design tokens 優先

### Backend

- Node.js
- Fastify
- TypeScript
- MQTT.js
- Socket.IO 優先
- SQLite，優先使用 better-sqlite3
- OpenAPI 3.1
- Swagger UI `/docs`

### Database

- 使用 SQLite
- SQLite 必須儲存設定、圖片 metadata、播放設定、MQTT topic mapping、迴路設定、累積值、歷史快照、每日彙總、裝置事件
- 累積值不可因系統重啟而歸零
- MQTT tag/topic 必須可由設定頁管理，不可只寫死在程式碼

### API

- REST API 使用 OpenAPI 3.1 定義
- API 不需要登入、不需要權限、不需要 token
- 系統假設部署於內網 kiosk 或受控網段

### Realtime

- 後端用 MQTT.js 接收 broker 資料
- 後端將 MQTT topic payload 轉成 normalized metrics
- 後端透過 Socket.IO 推送給前端
- 前端收到 realtime event 後即時更新 dashboard

---

## 1. Monorepo 結構

請建立 pnpm workspace monorepo：

```txt
solar-display/
  apps/
    web/
      src/
        app/
        pages/
        components/
        layouts/
        stores/
        hooks/
        services/
        styles/
        types/
    server/
      src/
        app.ts
        server.ts
        config.ts
        routes/
        services/
        mqtt/
        realtime/
        db/
        schemas/
        utils/
  packages/
    shared/
      src/
        types/
        constants/
        schemas/
  data/
    solar-display.sqlite
  uploads/
    images/
  docs/
    openapi.yaml
    database-schema.sql
  scripts/
    backup-sqlite.sh
    install-systemd.sh
  package.json
  pnpm-workspace.yaml
  tsconfig.base.json
  README.md
```

---

## 2. 頁面範圍

展示播放頁：

1. Overview
2. Solar
3. Factory Circuit
4. Images
5. Sustainability

資料與管理頁：

6. Energy Trend Summary
7. Playback Settings
8. Image Management
9. MQTT Settings
10. Circuit Settings
11. Energy Data History
12. Offline Error Display
13. Slideshow Preview
14. Device Status Details

---

## 3. 全域 design tokens

請建立 CSS variables 與 TypeScript token definition。預設以 1920x1080 landscape kiosk 為主。

```ts
export const tokens = {
  colors: {
    bg: '#F7F6F1',
    surface: '#FFFFFF',
    surfaceSoft: '#FAF8F2',
    primary: '#4F7D3A',
    primaryDark: '#2F5F2A',
    primaryLight: '#DDE8D2',
    accentSolar: '#F5A623',
    warning: '#EF6B6B',
    info: '#4A90E2',
    success: '#4F7D3A',
    text: '#2F3333',
    textMuted: '#6E7672',
    border: '#DDD8CC',
    shadow: 'rgba(42, 47, 42, 0.12)'
  },
  radius: {
    sm: '8px',
    md: '14px',
    lg: '22px',
    xl: '32px',
    pill: '999px'
  },
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
    xxl: '48px'
  },
  font: {
    sans: '"Noto Sans TC", "Inter", system-ui, sans-serif',
    mono: '"Roboto Mono", monospace'
  },
  layout: {
    width: '1920px',
    height: '1080px',
    headerHeight: '132px',
    footerHeight: '96px'
  }
}
```

---

## 4. MQTT tag/topic 核心要求

系統要讀取現場 MQTT 發送的 tag/topic。所有 MQTT topic mapping 必須可設定，並存於 SQLite。

### 必須支援的 mapping 類型

1. Core metrics：
   - 即時發電功率 realTimePower
   - 今日發電量 todayGeneration
   - 累積發電量 totalGeneration
   - 今日 CO₂ 減量 todayCo2Reduction
   - 累積 CO₂ 減量 totalCo2Reduction
   - 自發自用電量 selfConsumptionEnergy
   - 用電量 consumptionEnergy
   - 自發自用比例 selfConsumptionRatio
   - 系統效率 systemEfficiency

2. Circuit metrics：
   - 生產線用電
   - 空調與環境設備
   - 照明系統
   - 辦公與公共區域
   - 充電設備 / 綠能設施
   - 其他基礎設施
   - 需允許新增、刪除、排序、啟用、停用

3. Device status metrics：
   - MQTT status
   - last message time
   - local IP
   - CPU / memory / disk / temperature

### Topic 不可硬編

可以提供 seed 預設值，但 runtime 必須讀 SQLite 設定：

```txt
kuozui/plant/solar/power
kuozui/plant/solar/today_energy
kuozui/plant/solar/total_energy
kuozui/plant/solar/today_co2
kuozui/plant/solar/total_co2
kuozui/plant/solar/self_consumption
kuozui/plant/solar/consumption
kuozui/plant/solar/self_consumption_ratio
kuozui/plant/solar/system_efficiency
factory/power/production
factory/power/hvac
factory/power/lighting
factory/power/office
factory/power/ev_green
factory/power/infrastructure
```

### Payload parser 必須支援

```json
{ "value": 586, "unit": "kW", "timestamp": "2025-05-26T09:42:18+08:00", "quality": "good" }
```

也必須支援：

```txt
586
```

與：

```txt
"586"
```

以及可設定 value path，例如：

```json
{ "data": { "power": 586 } }
```

若 value path 設定為 `data.power`，parser 要讀到 586。

---

# Phase 1 — Monorepo、基礎架構、OpenAPI、SQLite 初始化

## 目標

建立可執行的前後端專案骨架，完成 SQLite 初始化、OpenAPI 文件入口、shared types。

## 範圍

Frontend：
- Vite + React + TypeScript
- Router
- LayoutShell
- Header / Footer placeholder
- tokens.css

Backend：
- Fastify TypeScript server
- `/health`
- `/docs`
- OpenAPI yaml 載入
- SQLite connection
- migration runner
- seed default settings

Shared：
- ApiResponse
- MetricKey
- MqttTopicMapping
- PlaybackPage
- CircuitConfig

## 產出

- 可啟動 monorepo
- SQLite DB 自動建立
- OpenAPI 可瀏覽
- README 有啟動方式

---

# Phase 2 — UI Shell 與 14 個頁面骨架

## 目標

建立完整畫面路由與一致的 kiosk shell。

## 範圍

- 建立 14 個頁面 component
- 建立 AppHeader、FooterNav、PageContainer、MetricCard、PanelCard、StatusBadge、IconCircle、Sparkline、BilingualLabel
- Header 顯示 logo、系統名、時間、日期、天氣 mock、MQTT 狀態
- Footer 顯示頁碼、tabs、slogan、leaf ornament

## 產出

- 所有頁面可進入
- 1920x1080 不爆版
- 可用 mock data 顯示基本內容

---

# Phase 3 — Mock Data Layer 與展示頁實作

## 目標

用 mock data 完成五個播放展示頁。

## 範圍

- Overview：五張 KPI 卡、hero image、slogan
- Solar：太陽能板 → 變流器 → 工廠用電 / CO₂ 效益流程
- Factory Circuit：太陽能板 → 逆變器 → 配電盤 → 各迴路
- Images：大圖、縮圖、圖片資訊卡、自動輪播 placeholder
- Sustainability：累積發電、累積 CO₂、節能、綠色採購、ESG、種樹

Backend：
- `/api/metrics/live`
- `/api/circuits`
- `/api/images`
- mock fallback

---

# Phase 4 — MQTT.js 整合與 MQTT Settings

## 目標

後端可連接 MQTT broker，訂閱 SQLite 設定的 topic，解析 payload，更新 live metrics cache。

## 範圍

Backend：
- MqttClientService
- TopicMappingRepository
- PayloadParser
- MqttStatusService
- MQTT mode / mock mode
- topic mapping reload
- test connection API

Frontend：
- MQTT Settings 頁
- broker host / port / username / password / clientId / reconnect interval / timeout
- Live topic list
- Topic mapping 設定
- Live data preview
- Test connection
- Save settings

API：
- `GET /api/settings/mqtt`
- `PUT /api/settings/mqtt`
- `POST /api/settings/mqtt/test`
- `GET /api/settings/mqtt/topics`
- `PUT /api/settings/mqtt/topics`
- `POST /api/settings/mqtt/reload`

---

# Phase 5 — Socket.IO 即時推送與 Offline Error

## 目標

MQTT 更新後透過 Socket.IO 推送前端；斷線或資料逾時顯示 Offline Error。

## 範圍

Events：
- `liveMetrics:update`
- `mqtt:status`
- `circuitMetrics:update`
- `playback:settingsUpdated`
- `images:updated`
- `deviceStatus:update`
- `system:error`
- `system:recovered`

Frontend：
- socket client singleton
- useLiveMetrics
- useMqttStatus
- Offline Error Display
- reconnect countdown
- 連線恢復自動回原頁

---

# Phase 6 — SQLite 累積值、快照、歷史資料

## 目標

SQLite 保存累積值、每日彙總與歷史資料，系統重啟後不歸零。

## 範圍

Backend：
- MetricsAccumulatorService
- SnapshotWriterService
- DailySummaryService
- CO₂ emission factor setting
- kW 積分估算 kWh
- total value 優先使用 MQTT total

API：
- `GET /api/metrics/history?range=day|week|month|year|total`
- `GET /api/metrics/daily-summary`
- `GET /api/metrics/cumulative`

Frontend：
- Energy Trend Summary
- Energy Data History
- Recharts 趨勢圖
- day/week/month/total 切換

---

# Phase 7 — Playback Engine 播放系統

## 目標

實作自動播放、頁面順序、每頁停留秒數、loop、transition、schedule、idle mode。

## 範圍

Backend：
- playback settings API
- playback pages API

Frontend：
- usePlaybackController
- usePageRotation
- useCountdown
- Playback Settings 頁
- Slideshow Preview 頁
- route preview
- autoplay / loop / duration / start page / transition / schedule / idle mode / brightness / orientation

---

# Phase 8 — Image Management 圖片管理

## 目標

圖片上傳、metadata、加入輪播、排序、刪除、空間統計。

## 範圍

Backend：
- multipart upload
- image metadata
- storage usage
- image delete 同步刪除檔案

Frontend：
- Image Management 頁
- image grid
- edit panel
- upload dropzone
- include in slideshow
- set cover
- display duration
- aspect ratio
- Images 播放頁讀取啟用圖片

---

# Phase 9 — Circuit Settings 與 Factory Circuit 動態化

## 目標

用電迴路設定可由 UI 管理，Factory Circuit 頁根據設定與 MQTT tag 動態顯示。

## 範圍

Backend：
- Circuit CRUD
- reorder
- show/hide
- rated capacity
- threshold status
- circuit MQTT topic mapping

Frontend：
- Circuit Settings 頁
- 新增 / 刪除 / 修改 / 排序 / 啟用停用
- Factory Circuit 依 circuit_configs render
- normal / attention / warning / offline 狀態

---

# Phase 10 — Device Status、部署、穩定化、最終驗收

## 目標

完成裝置狀態、部署腳本、錯誤處理、日誌與最終整合。

## 範圍

Backend：
- Device Status API
- logs API
- export logs
- clear cache
- reboot stub
- system update stub

Deployment：
- Raspberry Pi systemd service
- Chromium kiosk mode
- `.env.example`
- production build script
- SQLite backup script
- log rotation 建議

Final：
- build
- typecheck
- lint
- smoke test
- MQTT mode test
- mock mode test
- API docs verify

---

## 最終完成定義

完成後系統必須具備：

- 展示頁可自動播放
- MQTT live data 可即時更新
- MQTT tag/topic 可由設定頁管理
- SQLite 可保存累積值
- 歷史趨勢可查詢
- 圖片可管理與輪播
- 播放順序與秒數可設定
- 用電迴路可設定
- Offline Error Display 正確顯示
- Device Status 顯示設備資訊
- OpenAPI 文件完整
- Raspberry Pi 可部署
- 無登入權限
- 內網 kiosk 可長時間穩定播放
