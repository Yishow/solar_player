# Solar Display System — 驗收清單 Acceptance Checklist

> 所有驗收項目都以「可執行、可操作、可觀察」為標準。不能只完成 UI mock，必須確認資料流、SQLite 保存、OpenAPI 文件與 realtime 行為。

---

## A. 全系統驗收

- [ ] 使用 `pnpm install` 可安裝所有依賴
- [ ] 使用 `pnpm dev` 可同時啟動 web 與 server
- [ ] 使用 `pnpm build` 可成功 build frontend 與 backend
- [ ] 使用 `pnpm typecheck` 無 TypeScript 錯誤
- [ ] 使用 `pnpm lint` 無重大 lint 錯誤
- [ ] Frontend 預設可進入 kiosk 播放頁
- [ ] Backend `/health` 回傳 success
- [ ] Backend `/docs` 可顯示 OpenAPI 文件
- [ ] SQLite database 可自動建立
- [ ] SQLite schema 可重複 migration，不重複建立錯誤資料
- [ ] 系統不要求登入、不要求權限、不要求 token
- [ ] 所有 API response 格式一致

---

## B. 前端 UI 驗收

- [ ] 1920x1080 解析度下畫面不爆版
- [ ] Header 固定高度一致
- [ ] Footer 固定高度一致
- [ ] Header 顯示 logo、系統名稱、時間、日期、天氣、MQTT 狀態
- [ ] Footer 顯示頁碼、navigation tabs、slogan
- [ ] 所有卡片使用一致 radius、shadow、border、spacing
- [ ] 主要色彩符合 design tokens
- [ ] 所有播放頁適合遠距離觀看，大數字清楚
- [ ] 中英雙語 label 排版一致
- [ ] 所有管理頁表單可操作
- [ ] loading state 清楚
- [ ] empty state 清楚
- [ ] error state 清楚

---

## C. 14 頁頁面驗收

### 1. Overview

- [ ] 顯示即時發電功率
- [ ] 顯示今日發電量
- [ ] 顯示累積發電量
- [ ] 顯示今日 CO₂ 減量
- [ ] 顯示累積 CO₂ 減量
- [ ] 即時資料更新時 KPI 會更新
- [ ] MQTT offline 時不顯示誤導性 live 狀態

### 2. Solar

- [ ] 顯示太陽能板、變流器、工廠用電、減碳效益流程
- [ ] KPI cards 顯示今日發電量、自發自用比例、今日 CO₂、累積 CO₂、系統效率
- [ ] 系統效率資料可從 MQTT topic mapping 取得或 mock fallback

### 3. Factory Circuit

- [ ] 迴路列表由 SQLite `circuit_configs` 動態產生
- [ ] 每個迴路顯示 name zh/en、icon、百分比、狀態
- [ ] 迴路功率從 MQTT circuit topic 更新
- [ ] 隱藏迴路不顯示
- [ ] warning / attention / normal 狀態正確

### 4. Images

- [ ] 可顯示啟用圖片
- [ ] 可顯示縮圖
- [ ] 可顯示標題與描述
- [ ] 圖片輪播依 display duration 運作
- [ ] 沒有圖片時顯示 empty state

### 5. Sustainability

- [ ] 顯示累積發電量
- [ ] 顯示累積 CO₂ 減量
- [ ] 顯示年度節能成效
- [ ] 顯示綠色採購金額
- [ ] 顯示 ESG highlights
- [ ] 顯示相當於種樹數

### 6. Energy Trend Summary

- [ ] day/week/month/total 切換可操作
- [ ] 圖表使用 SQLite history data
- [ ] 顯示 Power、Energy、Consumption、Self-consumption、CO₂ Reduction
- [ ] 資料更新時間顯示正確

### 7. Playback Settings

- [ ] 可設定播放順序
- [ ] 可設定每頁停留秒數
- [ ] 可設定 autoplay
- [ ] 可設定 loop mode
- [ ] 可設定 start page
- [ ] 可設定 transition
- [ ] 可設定 schedule
- [ ] 儲存後立即生效

### 8. Image Management

- [ ] 可上傳 JPG / PNG / WebP
- [ ] 可編輯標題
- [ ] 可編輯描述
- [ ] 可設定顯示秒數
- [ ] 可加入/移出輪播
- [ ] 可設為封面
- [ ] 可刪除圖片
- [ ] storage usage 正確

### 9. MQTT Settings

- [ ] 可切換 MQTT / Mock mode
- [ ] 可設定 broker host
- [ ] 可設定 port
- [ ] 可設定 username/password
- [ ] 可設定 clientId
- [ ] 可設定 reconnect interval
- [ ] 可設定 message timeout
- [ ] 可測試連線
- [ ] 可儲存設定
- [ ] 可編輯 core metric topic mapping
- [ ] 可編輯 topic value path
- [ ] 可查看 live data preview
- [ ] 儲存後 MQTT service reload topics

### 10. Circuit Settings

- [ ] 可新增迴路
- [ ] 可刪除迴路
- [ ] 可修改迴路名稱
- [ ] 可修改 icon
- [ ] 可修改 unit
- [ ] 可修改 MQTT topic
- [ ] 可修改 rated capacity
- [ ] 可修改 normal/attention/warning thresholds
- [ ] 可排序
- [ ] 可開關顯示
- [ ] 儲存後 Factory Circuit 立即更新

### 11. Energy Data History

- [ ] 顯示今日發電量
- [ ] 顯示自發自用電量
- [ ] 顯示用電量
- [ ] 顯示自發自用比例
- [ ] 顯示 CO₂ 減量
- [ ] 顯示今日趨勢圖
- [ ] 顯示峰值發電與峰值用電

### 12. Offline Error Display

- [ ] MQTT disconnected 時顯示
- [ ] MQTT connected 但 timeout 無資料時顯示
- [ ] 顯示最後更新時間
- [ ] 顯示錯誤原因
- [ ] 顯示建議處理方式
- [ ] 顯示重試倒數
- [ ] 恢復資料後回到原播放頁

### 13. Slideshow Preview

- [ ] 顯示播放狀態
- [ ] 顯示目前頁面
- [ ] 顯示下一頁倒數
- [ ] 顯示頁面卡片列表
- [ ] 顯示播放設定摘要
- [ ] 設定變更後同步更新

### 14. Device Status Details

- [ ] 顯示正常運作 / 異常狀態
- [ ] 顯示 uptime
- [ ] 顯示 last reboot
- [ ] 顯示 device name
- [ ] 顯示 model
- [ ] 顯示 OS
- [ ] 顯示 app version
- [ ] 顯示 local IP
- [ ] 顯示 MAC address
- [ ] 顯示 MQTT status
- [ ] 顯示 CPU / memory / disk / temperature
- [ ] Export logs 可下載

---

## D. MQTT 驗收

- [ ] MQTT broker 設定從 SQLite 載入
- [ ] topic mappings 從 SQLite 載入
- [ ] topic 不依賴硬編陣列才能運作
- [ ] 啟動後會訂閱 enabled topic mappings
- [ ] 修改 topic mapping 後可重新訂閱
- [ ] 支援 core metrics topic
- [ ] 支援 circuit metrics topic
- [ ] 支援 number payload
- [ ] 支援 string number payload
- [ ] 支援 JSON `{ value }` payload
- [ ] 支援 JSON nested path payload
- [ ] 支援 unit override
- [ ] 支援 multiplier/offset
- [ ] payload 解析失敗會 log，但不 crash
- [ ] MQTT disconnected 會進入 offline/stale 流程
- [ ] broker reconnect 後可恢復訂閱
- [ ] Live Data Preview 顯示最後接收值與時間

---

## E. Socket.IO 驗收

- [ ] client 連線成功
- [ ] server 推送 `mqtt:status`
- [ ] server 推送 `liveMetrics:update`
- [ ] server 推送 `circuitMetrics:update`
- [ ] 設定改變推送 `playback:settingsUpdated`
- [ ] 圖片改變推送 `images:updated`
- [ ] 斷線後 client 自動重連
- [ ] 重連後不產生重複 listener
- [ ] 前端卸載 component 會 cleanup listener

---

## F. SQLite 驗收

- [ ] MQTT settings 可保存
- [ ] topic mappings 可保存
- [ ] circuit configs 可保存
- [ ] playback settings 可保存
- [ ] image assets metadata 可保存
- [ ] cumulative counters 可保存
- [ ] metric snapshots 可保存
- [ ] daily summaries 可保存
- [ ] 系統重啟後累積值不歸零
- [ ] 系統重啟後 topic mapping 不遺失
- [ ] 系統重啟後 playback settings 不遺失
- [ ] 系統重啟後 circuit configs 不遺失
- [ ] SQLite 備份腳本可執行

---

## G. OpenAPI 驗收

- [ ] `docs/openapi.yaml` 存在
- [ ] `/docs` 可瀏覽
- [ ] 所有 Metrics API 有定義
- [ ] 所有 MQTT API 有定義
- [ ] 所有 Playback API 有定義
- [ ] 所有 Images API 有定義
- [ ] 所有 Circuits API 有定義
- [ ] 所有 Device API 有定義
- [ ] 所有 request body schema 有定義
- [ ] 所有 response schema 有定義
- [ ] 所有 error response 有定義
- [ ] OpenAPI schema 與實際 API 一致

---

## H. 部署驗收

- [ ] Raspberry Pi / Linux 可安裝 Node.js 與 pnpm
- [ ] production build 可啟動
- [ ] systemd service 可自動啟動 server
- [ ] Chromium kiosk script 可打開前端
- [ ] reboot 後可自動進入播放頁
- [ ] uploads/images 目錄權限正確
- [ ] data 目錄權限正確
- [ ] SQLite 備份可建立
- [ ] log 可匯出
- [ ] 長時間播放 8 小時以上不明顯 memory leak
