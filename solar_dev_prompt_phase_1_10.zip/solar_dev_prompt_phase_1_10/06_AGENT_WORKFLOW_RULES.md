# Agent Workflow Rules — 給 Coding Agent 的實作規則

這份規則用來約束 AI coding agent，避免一次產生過多不可執行的程式碼，或忽略 MQTT / SQLite / OpenAPI 的核心需求。

---

## 1. Phase 執行規則

1. 一次只做一個 Phase。
2. 完成該 Phase 後停止，等待使用者確認。
3. 不要在 Phase 1 就實作 Phase 8 的圖片上傳完整功能。
4. 可以預留 interface，但不要過度實作。
5. 每個 Phase 結束前必須跑：
   - install check
   - typecheck
   - build
   - server startup check
   - frontend startup check
6. 若有測試，必須跑 tests。
7. 每次新增 API，必須更新 OpenAPI。
8. 每次新增 table，必須更新 database schema 文件。

---

## 2. 不可違反的產品規則

- [ ] 不做登入
- [ ] 不做權限
- [ ] 不做 JWT
- [ ] 不做 OAuth
- [ ] 不做多租戶
- [ ] 不做雲端帳號
- [ ] 不做付款
- [ ] 不把 MQTT topic 寫死成唯一設定來源
- [ ] 不讓累積值只存在記憶體
- [ ] 不讓 MQTT parser 因單筆壞 payload crash
- [ ] 不讓前端每次 render 建立新的 socket connection
- [ ] 不讓設定儲存後只更新 UI 而沒有寫 SQLite

---

## 3. TypeScript 規則

- 使用 strict mode。
- 避免 `any`。
- API request/response 要有型別。
- 共用型別放 `packages/shared`。
- parser 輸入輸出要有明確 type。
- 不要讓前端自行猜後端 response shape。

---

## 4. SQLite 規則

- 所有設定都寫入 SQLite。
- cumulative counters 啟動時必須從 SQLite 載入。
- migrations 必須 idempotent。
- seed data 不可覆蓋使用者已修改設定。
- 高頻 MQTT 不可每筆都同步重寫大量資料。
- snapshots 建議節流 30–60 秒。
- SQLite 寫入錯誤要 log 並回傳友善 error。

---

## 5. MQTT 實作規則

- MQTT settings 從 SQLite 讀取。
- topic mappings 從 SQLite 讀取。
- circuit MQTT topics 從 SQLite 讀取。
- broker 設定更新後要重新連線。
- topic mapping 更新後要重新訂閱。
- 支援 mock mode。
- 支援 connected / disconnected / reconnecting / stale / error。
- 支援 value path。
- 支援 multiplier / offset。
- 支援 last raw payload debug。
- 壞 payload 不可以中斷 service。

---

## 6. Socket.IO 規則

- 後端只建立一個 Socket.IO server。
- 前端只建立一個 socket singleton。
- React hooks 必須 cleanup listener。
- 重連後不可重複註冊 listener。
- MQTT 資料進來後廣播 normalized data，不要廣播原始不可控 payload 作為主要資料。
- raw payload 僅用於 debug preview。

---

## 7. UI 實作規則

- 優先完成 layout 與資料流，再補動畫。
- 播放頁不應需要 scroll。
- 管理頁可 scroll。
- 主要 KPI 數字要大。
- 中英雙語 label 一致。
- 綠色主色與米白背景要由 tokens 控制。
- 不要在 component 裡到處硬寫顏色。

---

## 8. 錯誤處理規則

每個錯誤都要有：

1. log entry
2. user-friendly message
3. stable fallback
4. 不 crash process

必須處理：

- MQTT broker 連不上
- MQTT 連上但沒有 message
- MQTT payload 格式錯誤
- SQLite 寫入失敗
- 圖片上傳格式錯誤
- 圖片容量超限
- Socket.IO 斷線重連
- API request 失敗
- 設定資料不合法
- Raspberry Pi 系統資訊讀取失敗

---

## 9. Phase 完成交付格式

每個 Phase 完成後，請回報：

```md
## Phase X 完成回報

### 已完成
- ...

### 修改檔案
- ...

### 如何啟動
- ...

### 如何測試
- ...

### 已跑檢查
- [ ] pnpm typecheck
- [ ] pnpm build
- [ ] pnpm test
- [ ] API smoke test

### 尚未做，留到後續 Phase
- ...
```

---

## 10. 最小測試要求

### Unit tests

- Payload parser
- Topic mapping normalization
- Accumulator calculation
- Threshold status calculation
- API response helper

### Integration tests

- SQLite migration
- MQTT mock message -> live cache
- live cache -> Socket.IO event
- settings save -> SQLite -> service reload

### Smoke tests

- `/health`
- `/docs`
- `/api/metrics/live`
- `/api/settings/mqtt`
- `/api/settings/mqtt/topics`
- `/api/circuits`
- `/api/playback/settings`

---

## 11. 開發優先序

若時間不足，優先順序如下：

1. 可啟動 monorepo
2. SQLite schema 與設定保存
3. MQTT topic mapping 可設定
4. MQTT parser 穩定
5. Socket.IO 即時更新
6. 五個播放頁可正常播放
7. 播放設定
8. 圖片管理
9. 歷史資料
10. 裝置狀態與部署細節
