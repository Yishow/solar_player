# MQTT Tag Reading & Settings Spec — MQTT 讀取與設定完整規格

本系統的關鍵不是只寫死幾個 topic，而是要能在設定頁維護 MQTT broker 與 tag/topic mapping。現場 MQTT 發送格式可能不同，因此後端 parser 要具備彈性，前端設定頁要能讓使用者把現場 tag 對應到系統需要的指標。

---

## 1. 核心原則

1. MQTT topic mapping 必須存 SQLite。
2. 程式碼只能提供 seed default topics，不可以把 topic 寫死成唯一資料來源。
3. 後端啟動時從 SQLite 載入 enabled topic mappings。
4. MQTT Settings 頁儲存後，後端必須 reload topic subscriptions。
5. Circuit Settings 頁的 circuit MQTT topic 也是 tag mapping 的一部分。
6. Payload parser 必須支援多種 payload 格式。
7. Live data preview 必須顯示每個 topic 最近值、單位、品質、時間、raw payload。
8. MQTT offline/stale 不可讓 UI 假裝資料仍然正常。

---

## 2. MQTT broker 設定

### TypeScript model

```ts
export type MqttDataMode = 'mqtt' | 'mock'

export type MqttConnectionStatus =
  | 'disabled'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'disconnected'
  | 'stale'
  | 'error'

export interface MqttSettings {
  enabled: boolean
  mode: MqttDataMode
  brokerUrl: string
  port: number
  username?: string
  password?: string
  clientId: string
  reconnectIntervalSec: number
  messageTimeoutSec: number
  keepaliveSec: number
  clean: boolean
  protocol: 'mqtt' | 'mqtts' | 'ws' | 'wss'
  lastConnectionStatus: MqttConnectionStatus
  lastMessageAt?: string
  updatedAt: string
}
```

### UI 欄位

| 欄位 | 必填 | 預設 | 說明 |
|---|---:|---:|---|
| Data Mode | 是 | MQTT | MQTT 或 Mock |
| Broker Host / URL | 是 | localhost | Broker 位址 |
| Port | 是 | 1883 | MQTT 預設 1883 |
| Protocol | 是 | mqtt | mqtt/mqtts/ws/wss |
| Username | 否 | 空 | 有帳密才填 |
| Password | 否 | 空 | API 不回傳明文 |
| Client ID | 是 | kuozui-green-display-01 | 唯一 client id |
| Reconnect Interval | 是 | 30 sec | 重連間隔 |
| Message Timeout | 是 | 60 sec | 超過此秒數沒資料視為 stale |
| Keepalive | 是 | 60 sec | MQTT keepalive |
| Clean Session | 是 | true | MQTT clean |

---

## 3. Topic mapping 分類

### 3.1 Core metric mappings

Core metric 是系統 dashboard 主要 KPI。

```ts
export type CoreMetricKey =
  | 'realTimePowerKw'
  | 'todayGenerationKwh'
  | 'totalGenerationKwh'
  | 'todayCo2ReductionT'
  | 'totalCo2ReductionT'
  | 'selfConsumptionKwh'
  | 'consumptionKwh'
  | 'selfConsumptionRatioPct'
  | 'systemEfficiencyPct'
```

### 3.2 Circuit metric mappings

Circuit metric 是用電迴路。每個 circuit 都有自己的 MQTT topic。

```ts
export interface CircuitConfig {
  id: string
  displayOrder: number
  nameZh: string
  nameEn: string
  icon: string
  unit: 'kW' | 'W' | 'A' | 'kWh'
  mqttTopic: string
  valuePath?: string
  multiplier: number
  offset: number
  ratedCapacity: number
  normalMin: number
  normalMax: number
  attentionMin: number
  attentionMax: number
  warningMin: number
  warningMax: number
  show: boolean
}
```

### 3.3 Device / system mappings

裝置狀態通常由後端讀取本機系統資訊，不一定從 MQTT 來。但保留未來可用 MQTT 補充：

- device temperature
- network signal
- inverter status
- grid status
- battery status if future expansion

---

## 4. 預設 MQTT topic seed

> 以下僅作為初始 seed，使用者可在 MQTT Settings 與 Circuit Settings 修改。

| Metric Key | 預設 Topic | 單位 | Label |
|---|---|---:|---|
| `realTimePowerKw` | `kuozui/plant/solar/power` | kW | 即時發電功率 |
| `todayGenerationKwh` | `kuozui/plant/solar/today_energy` | kWh | 今日發電量 |
| `totalGenerationKwh` | `kuozui/plant/solar/total_energy` | kWh | 累積發電量 |
| `todayCo2ReductionT` | `kuozui/plant/solar/today_co2` | t | 今日 CO₂ 減量 |
| `totalCo2ReductionT` | `kuozui/plant/solar/total_co2` | t | 累積 CO₂ 減量 |
| `selfConsumptionKwh` | `kuozui/plant/solar/self_consumption` | kWh | 自發自用電量 |
| `consumptionKwh` | `kuozui/plant/solar/consumption` | kWh | 用電量 |
| `selfConsumptionRatioPct` | `kuozui/plant/solar/self_consumption_ratio` | % | 自發自用比例 |
| `systemEfficiencyPct` | `kuozui/plant/solar/system_efficiency` | % | 系統效率 |

### Circuit default seed

| Circuit | 預設 Topic | 單位 | Rated Capacity |
|---|---|---:|---:|
| 生產線用電 | `factory/power/production` | kW | 4000 |
| 空調與環境設備 | `factory/power/hvac` | kW | 2000 |
| 照明系統 | `factory/power/lighting` | kW | 1000 |
| 辦公與公共區域 | `factory/power/office` | kW | 1000 |
| 充電設備 / 綠能設施 | `factory/power/ev_green` | kW | 1000 |
| 其他基礎設施 | `factory/power/infrastructure` | kW | 800 |

---

## 5. Topic mapping schema

```ts
export interface MqttTopicMapping {
  id: string
  mappingType: 'core' | 'circuit' | 'device' | 'custom'
  metricKey: string
  labelZh: string
  labelEn: string
  topic: string
  unit: string
  enabled: boolean
  valuePath?: string
  timestampPath?: string
  qualityPath?: string
  multiplier: number
  offset: number
  decimals?: number
  minValue?: number
  maxValue?: number
  staleAfterSec?: number
  lastValue?: number
  lastRawPayload?: string
  lastReceivedAt?: string
  lastQuality?: 'good' | 'stale' | 'bad'
  createdAt: string
  updatedAt: string
}
```

### valuePath 規則

| Payload | valuePath | 解析結果 |
|---|---|---:|
| `586` | 空 | 586 |
| `"586"` | 空 | 586 |
| `{ "value": 586 }` | `value` 或空 | 586 |
| `{ "data": { "power": 586 } }` | `data.power` | 586 |
| `{ "metrics": [{ "value": 586 }] }` | `metrics.0.value` | 586 |

---

## 6. Payload parser 規格

### Parser input

```ts
export interface ParseMqttPayloadInput {
  topic: string
  rawPayload: Buffer | string
  mapping: MqttTopicMapping
  receivedAt: string
}
```

### Parser output

```ts
export interface ParsedMqttValue {
  topic: string
  metricKey: string
  mappingType: MqttTopicMapping['mappingType']
  value: number
  unit: string
  timestamp: string
  quality: 'good' | 'stale' | 'bad'
  raw: string
  error?: string
}
```

### Parser 流程

1. Buffer 轉 UTF-8 string。
2. trim raw string。
3. 嘗試 JSON.parse。
4. 如果 mapping.valuePath 存在，用 dot-path 取值。
5. 如果沒有 valuePath：
   - 若 JSON object 有 `value`，用 `value`
   - 若 JSON object 有 `data.value`，可作 fallback
   - 若 raw 是 number string，直接 Number(raw)
6. 轉成 number。
7. 套用 `value = value * multiplier + offset`。
8. 套用 decimals rounding。
9. 驗證 min/max。
10. 解析 timestamp：
    - mapping.timestampPath
    - payload.timestamp
    - receivedAt
11. 解析 quality：
    - mapping.qualityPath
    - payload.quality
    - good
12. 若失敗，回傳 bad quality 並寫 log，不 throw 讓 service crash。

---

## 7. MQTT service 行為

### 啟動流程

1. 從 SQLite 讀取 mqtt_settings。
2. 若 mode = mock，不連 MQTT，啟動 mock generator。
3. 若 enabled = false，不連 MQTT。
4. 從 SQLite 讀取 enabled topic_mappings。
5. 從 SQLite 讀取 enabled circuit_configs 的 mqttTopic。
6. 建立 MQTT client。
7. connect 後訂閱 topics。
8. 收到 message 後找 mapping。
9. parse payload。
10. 更新 live metric cache。
11. 寫入 live_metric_values。
12. 廣播 Socket.IO event。
13. 視條件寫入 snapshot / accumulator。

### reload topic 流程

當 MQTT Settings 或 Circuit Settings 改變：

1. 儲存 SQLite。
2. 發出 internal event `mqtt:reloadRequested`。
3. MQTT service 取消舊 subscription。
4. 重新讀取 topic mappings。
5. 重新 subscribe。
6. 推送 `mqtt:status` 與 live topic list。

---

## 8. Live Data Preview 規格

MQTT Settings 右側「即時資料預覽」要顯示：

| 欄位 | 說明 |
|---|---|
| Label | 中文/英文名稱 |
| Metric Key | 系統指標 key |
| Topic | MQTT topic |
| Value | 最後解析值 |
| Unit | 單位 |
| Quality | good/stale/bad |
| Last Received | 最後收到時間 |
| Raw Payload | 最近 payload，可在 debug panel 顯示 |

---

## 9. Online / stale / offline 判斷

### MQTT status

| 狀態 | 條件 |
|---|---|
| disabled | MQTT disabled |
| connecting | 正在連線 |
| connected | MQTT client connected 且有資料 |
| reconnecting | MQTT 正在重連 |
| disconnected | MQTT client disconnected |
| stale | MQTT client connected，但核心 topic 超過 timeout 無資料 |
| error | auth error、network error 或 parser critical error |

### 核心 topic 判斷

至少以下任一核心 topic 在 timeout 內收到 good quality，可視為 live data online：

- `realTimePowerKw`
- `todayGenerationKwh`
- `totalGenerationKwh`

若三者全部超過 timeout，顯示 stale / Offline Error Display。

---

## 10. REST API

### MQTT settings

```http
GET /api/settings/mqtt
PUT /api/settings/mqtt
POST /api/settings/mqtt/test
POST /api/settings/mqtt/reload
```

### Topic mappings

```http
GET /api/settings/mqtt/topics
POST /api/settings/mqtt/topics
PUT /api/settings/mqtt/topics/{id}
DELETE /api/settings/mqtt/topics/{id}
PUT /api/settings/mqtt/topics/reorder
```

### Live preview

```http
GET /api/settings/mqtt/live-preview
```

Response：

```json
{
  "success": true,
  "data": [
    {
      "metricKey": "realTimePowerKw",
      "topic": "kuozui/plant/solar/power",
      "value": 586,
      "unit": "kW",
      "quality": "good",
      "lastReceivedAt": "2025-05-26T09:42:18+08:00",
      "rawPayload": "{\"value\":586}"
    }
  ]
}
```

---

## 11. SQLite tables

### `mqtt_settings`

| 欄位 | 型別 | 說明 |
|---|---|---|
| id | INTEGER | 固定 1 |
| enabled | INTEGER | 0/1 |
| mode | TEXT | mqtt/mock |
| protocol | TEXT | mqtt/mqtts/ws/wss |
| broker_url | TEXT | broker host/url |
| port | INTEGER | port |
| username | TEXT | username |
| password_encrypted | TEXT | password，不回傳明文 |
| client_id | TEXT | MQTT client id |
| reconnect_interval_sec | INTEGER | reconnect 秒數 |
| message_timeout_sec | INTEGER | timeout 秒數 |
| keepalive_sec | INTEGER | keepalive |
| clean | INTEGER | clean session |
| last_connection_status | TEXT | status |
| last_message_at | TEXT | 最後資料時間 |
| updated_at | TEXT | 更新時間 |

### `topic_mappings`

| 欄位 | 型別 | 說明 |
|---|---|---|
| id | TEXT | UUID |
| mapping_type | TEXT | core/circuit/device/custom |
| metric_key | TEXT | 系統指標 key |
| label_zh | TEXT | 中文名稱 |
| label_en | TEXT | 英文名稱 |
| topic | TEXT | MQTT topic |
| unit | TEXT | 單位 |
| enabled | INTEGER | 是否啟用 |
| value_path | TEXT | JSON value path |
| timestamp_path | TEXT | JSON timestamp path |
| quality_path | TEXT | JSON quality path |
| multiplier | REAL | 乘數 |
| offset | REAL | 偏移 |
| decimals | INTEGER | 小數位 |
| min_value | REAL | 最小值 |
| max_value | REAL | 最大值 |
| stale_after_sec | INTEGER | stale 秒數 |
| display_order | INTEGER | 排序 |
| created_at | TEXT | 建立時間 |
| updated_at | TEXT | 更新時間 |

### `live_metric_values`

儲存每個 topic/metric 的最後值，供設定頁 preview 與系統重啟後初始畫面使用。

---

## 12. 測試案例

### Payload parser 測試

- [ ] raw `586` parse 成 586
- [ ] raw `"586"` parse 成 586
- [ ] raw `{ "value": 586 }` parse 成 586
- [ ] raw `{ "data": { "power": 586 } }` + valuePath `data.power` parse 成 586
- [ ] multiplier 0.001 可將 W 轉 kW
- [ ] offset 可被套用
- [ ] min/max 超出時標記 bad
- [ ] invalid JSON 不 crash
- [ ] missing valuePath 不 crash

### MQTT integration 測試

- [ ] broker connected 後訂閱所有 enabled topics
- [ ] 更新 topic mapping 後舊 topic unsubscribe
- [ ] 更新 topic mapping 後新 topic subscribe
- [ ] 收到 core topic 後更新 live metrics
- [ ] 收到 circuit topic 後更新 circuit metrics
- [ ] timeout 後 status 變 stale
- [ ] reconnect 後 status 變 connected
