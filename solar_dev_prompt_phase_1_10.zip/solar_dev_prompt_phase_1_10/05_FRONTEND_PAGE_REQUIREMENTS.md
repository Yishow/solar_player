# Frontend Page Requirements — 14 頁需求整理

本系統以 1920x1080 kiosk display 為主要輸出，所有畫面需維持一致 header/footer、綠色永續視覺語言、卡片式資訊架構。

---

## Common Layout

### Header

- Logo / 品牌識別
- 中文系統名稱
- 英文系統名稱
- 目前時間
- 日期與星期
- 天氣資訊 mock 或 future API
- MQTT Online / Offline / Reconnecting 狀態

### Footer

- 頁碼 pill
- navigation tabs
- leaf icon
- slogan：永續，從現在開始 / Sustainability Starts with Us

### Common components

- MetricCard
- Sparkline
- PanelCard
- IconCircle
- StatusBadge
- SectionTitle
- FlowNode
- FlowConnector
- KioskTable
- KioskFormField
- KioskToggle
- KioskButton

---

## 1. Overview Page

### 目的

首頁總覽，讓觀眾快速理解目前太陽能系統的發電與減碳成果。

### 資料需求

- realTimePowerKw
- todayGenerationKwh
- totalGenerationKwh
- todayCo2ReductionT
- totalCo2ReductionT
- MQTT status
- hero image

### UI 需求

- 大型 hero 區
- 主標語「以綠色製造 驅動美好生活」
- KPI cards 橫向排列
- 每張 KPI card 有 icon、中文 label、英文 label、數值、單位、sparkline

---

## 2. Solar Page

### 目的

說明太陽能如何驅動工廠新能量。

### 資料需求

- todayGenerationKwh
- selfConsumptionRatioPct
- todayCo2ReductionT
- totalCo2ReductionT
- systemEfficiencyPct

### UI 需求

- 左側標題與說明
- 太陽能板、變流器、工廠用電、碳減量節點
- 流程箭頭
- KPI cards

---

## 3. Factory Circuit Page

### 目的

展示廠區用電回路與負載分布。

### 資料需求

- realTimePowerKw
- solarSupplyRatioPct
- todaySelfConsumptionKwh
- peakLoadKw
- gridFlowStatus
- circuit list from SQLite
- circuit live values from MQTT

### UI 需求

- 太陽能板 → 逆變器 → 配電盤 → 迴路清單
- 每個迴路顯示 icon、中文/英文名稱、負載百分比
- 依 threshold 顯示 normal / attention / warning
- bottom KPI cards

---

## 4. Images Page

### 目的

展示綠能現場影像，作為播放輪播的一部分。

### 資料需求

- enabled image assets
- selected image index
- display duration
- title
- description
- location label

### UI 需求

- 左側標題
- 大圖區
- 圖片說明卡
- thumbnails
- progress indicator
- prev/next buttons
- 自動每 N 秒切換圖片

---

## 5. Sustainability Page

### 目的

展示永續成果與 ESG 行動摘要。

### 資料需求

- totalGenerationGwh
- totalCo2ReductionT
- annualEnergySavingPct
- greenProcurementAmount
- esgHighlights
- treesPlanted

### UI 需求

- 大型背景圖
- 永續主標
- KPI cards
- ESG bullet card

---

## 6. Energy Trend Summary Page

### 目的

展示能源趨勢摘要，提供日/週/月/累積切換。

### 資料需求

- history data
- power series
- energy series
- consumption series
- selfConsumption ratio series
- CO₂ series
- last updated time

### UI 需求

- 篩選 tab：Day / Week / Month / Total
- 5 張趨勢卡
- 每張卡含圖表、當前值、單位
- 資料每 30 秒更新一次提示

---

## 7. Playback Settings Page

### 目的

設定播放頁順序、秒數、自動播放、排程、待機模式。

### 資料需求

- playback pages
- playback settings

### UI 需求

- rotation route preview
- page order list
- per-page duration editor
- autoplay toggle
- loop mode toggle
- start page select
- transition type select
- transition speed select
- schedule time select
- repeat days
- idle mode
- brightness
- orientation
- save settings

---

## 8. Image Management Page

### 目的

管理輪播圖片。

### 資料需求

- image assets
- storage usage
- upload folder path
- last sync time

### UI 需求

- total images card
- used space card
- last sync card
- source folder input
- upload dropzone
- image grid
- selected image edit panel
- title / description / duration / aspect ratio / include switch
- set as cover
- remove

---

## 9. MQTT Settings Page

### 目的

設定資料來源與 MQTT topic mapping，並提供 live data preview。

### 資料需求

- mqtt settings
- topic mappings
- live preview
- connection status
- last message time

### UI 需求

- data mode switch：MQTT / Mock
- broker host / port / username / password / clientId
- reconnect interval
- status indicator
- live topic list
- topic mapping form
- live data preview cards
- test connection
- save settings

### 關鍵要求

- topic mapping 必須可改
- core metrics topic 不可硬編
- valuePath 必須可設定
- 儲存後重新訂閱 MQTT topics

---

## 10. Circuit Settings Page

### 目的

設定廠區用電迴路與 MQTT topic。

### 資料需求

- circuit configs
- available icons
- unit list

### UI 需求

- table layout
- display order
- circuit name zh/en
- icon selector
- unit selector
- MQTT topic input
- threshold inputs normal / attention / warning
- show toggle
- add circuit
- save settings

---

## 11. Energy Data History Page

### 目的

提供較完整的能源歷史資料顯示。

### 資料需求

- generationKwh
- selfConsumptionKwh
- consumptionKwh
- selfConsumptionRatioPct
- co2ReductionT
- peakGenerationKw
- peakGenerationAt
- peakConsumptionKw
- peakConsumptionAt
- data source
- last update

### UI 需求

- 左側期間 selector：today/week/month/year/cumulative
- KPI cards
- large trend chart
- bottom summary cards

---

## 12. Offline Error Display Page

### 目的

當 MQTT 或即時資料不可用時，清楚告知現場人員。

### 資料需求

- lastUpdateTime
- errorReason
- suggestedAction
- retryCountdownSec
- mqttStatus

### UI 需求

- 大型 error icon
- 主訊息「無法取得即時資料」
- 英文訊息 Unable to retrieve live data
- reconnecting message
- info card：last update / error reason / suggested action
- retry countdown
- 背景仍保留品牌與綠能圖像

---

## 13. Slideshow Preview Page

### 目的

預覽輪播流程與目前播放狀態。

### 資料需求

- playback pages
- current page
- display duration
- next page countdown
- transition effect
- autoplay enabled
- last updated

### UI 需求

- playback status panel
- current page panel
- display duration panel
- carousel preview cards
- playback summary
- progress timeline

---

## 14. Device Status Details Page

### 目的

查看 Raspberry Pi / kiosk device 狀態。

### 資料需求

- operation status
- uptime
- last reboot
- device name
- model
- serial number
- OS
- app version
- local IP
- MAC address
- MQTT status
- data source
- CPU usage
- memory usage
- disk usage
- temperature
- network status
- signal strength

### UI 需求

- device operation card
- uptime card
- last reboot card
- device information table
- raspberry pi image / device image
- system resource monitor gauges
- action buttons：reboot / clear cache / system update / export logs

---

## Responsive / kiosk notes

- 主要鎖定 16:9 1920x1080
- 可用 CSS transform 或 fluid scale 支援 1366x768
- 字級不應過小，管理頁最小 14px，展示頁 KPI 數字至少 56px
- 播放頁避免 scroll
- 管理頁可允許 scroll，但 header/footer 建議固定
