# Solar Display System — 開發提示詞規格包

本壓縮檔提供給 Cursor / Claude Code / Codex / ChatGPT Coding Agent 使用，目標是實作「國瑞汽車中廠綠能展示播放器」類型的太陽能播放系統。

## 檔案說明

| 檔案 | 用途 |
|---|---|
| `00_MASTER_DEVELOPMENT_PROMPT.md` | 可直接貼給 coding agent 的完整系統開發提示詞 |
| `01_PHASE_1_TO_10_TASK_CHECKLIST.md` | Phase 1–10 任務 checklist |
| `02_ACCEPTANCE_CHECKLIST.md` | 系統、前端、後端、MQTT、SQLite、部署驗收清單 |
| `03_MQTT_TAG_READING_AND_SETTINGS_SPEC.md` | MQTT tag 讀取、topic mapping、設定頁、payload parser 規格 |
| `04_OPENAPI_AND_DATABASE_REQUIREMENTS.md` | OpenAPI 與 SQLite schema 要求 |
| `05_FRONTEND_PAGE_REQUIREMENTS.md` | 14 個頁面的前端需求整理 |
| `06_AGENT_WORKFLOW_RULES.md` | 給 AI coding agent 的實作規則與交付方式 |

## 建議使用方式

1. 先把 `00_MASTER_DEVELOPMENT_PROMPT.md` 貼給 coding agent。
2. 接著要求 agent：「只做 Phase 1，完成後停止」。
3. 每完成一個 phase，就用 `01_PHASE_1_TO_10_TASK_CHECKLIST.md` 勾核。
4. 每個 phase 結束後，用 `02_ACCEPTANCE_CHECKLIST.md` 做驗收。
5. MQTT tag 與設定頁實作時，必須以 `03_MQTT_TAG_READING_AND_SETTINGS_SPEC.md` 為準。

## 關鍵決策

- 前端：Vite + React + TypeScript
- 後端：Node.js + Fastify + TypeScript
- MQTT：MQTT.js
- 即時推送：Socket.IO 優先，可替換原生 WebSocket
- 資料庫：SQLite
- API 文件：OpenAPI 3.1
- 權限：不做登入、不做權限、不做 token
- MQTT tag：不得硬編在程式碼，必須可由設定頁與 SQLite 管理
